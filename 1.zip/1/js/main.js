$(function () {
  $(window).on('load', function () {
    $('body').addClass('loaded_hiding');
    window.setTimeout(function () {
      $('body').addClass('loaded');
      $('body').removeClass('loaded_hiding');
    }, 500);
  })
  $('.burger').on('click', function () {
    $('.header__menu-mob').addClass('header__menu-mob--active')
  })
  $('.header__menu-close').on('click', function () {
    $('.header__menu-mob').removeClass('header__menu-mob--active')
  })
  $('.header__menu-mob-link').on('click', function () {
    $('.header__menu-mob').removeClass('header__menu-mob--active')
  })
  $('.vsa-prog').on('click', function () {
    $(this).prev().slideToggle()
  })
  $('.zone__item-accord-body').on('click', function () {
    $('.zone').removeClass('zone--batyt')
  })
  $('.arenabatyt').on('click', function () {
    $('.zone').toggleClass('zone--batyt')
  })
  $('.zone__item-accord-body').on('click', function (e) {
    e.preventDefault()
    if ($(this).hasClass('zone__item-accord-body--active')) {
      $(this).removeClass('zone__item-accord-body--active')
      $(this).next('.zone__item-accord-inner').slideToggle()
      $('.zone__item-accord-body').removeClass('kakraz')
    } else {
      $('.zone__item-accord-body').removeClass('zone__item-accord-body--active')
      $('.zone__item-accord-inner').slideUp()
      $('.zone__item-accord-body').removeClass('kakraz')
      $(this).toggleClass('zone__item-accord-body--active')
      $(this).next('.zone__item-accord-inner').slideDown()
    }
  })
  setInterval(() => {
    if ($('.zone__item-accord-body').hasClass('kakraz')) {
      $('.zone__item-accord-body:first').addClass('zone__item-accord-body--active')
      $('.zone__item-accord-body:first').next('.zone__item-accord-inner').slideDown()
    } else {

    }
  }, 0);
  $('.fyd__item-body').on('click', function (e) {
    e.preventDefault()
    if ($(this).find('.fyd__item-menu').hasClass('fyd__item-menu--active')) {
      $(this).find('.fyd__item-menu').removeClass('fyd__item-menu--active')
      $(this).next().slideToggle()
    } else {
      $('.fyd__item-menu').removeClass('fyd__item-menu--active')
      $('.fyd__item-menu-block-wrap').slideUp()
      $(this).find('.fyd__item-menu').toggleClass('fyd__item-menu--active')
      $(this).next().slideDown()
    }
  })
  setInterval(() => {
    if ($(window).scrollTop() > 100) {
      $('.header__container').addClass('header__container--active')
    } else {
      $('.header__container').removeClass('header__container--active')
    }
  }, 0);
  let header = $('.header__container'),
    scrollPrev = 0;

  $(window).scroll(function () {
    let scrolled = $(window).scrollTop();

    if (scrolled > 100 && scrolled > scrollPrev) {
      header.addClass('out');
    } else {
      header.removeClass('out');
    }
    scrollPrev = scrolled;
  });
  $(window).scroll(function () {
    if ($(this).scrollTop() != 0) {
      $('#toTop').fadeIn();
    } else {
      $('#toTop').fadeOut();
    }
  });
  $('#toTop').click(function () {
    $('body,html').animate({ scrollTop: 0 }, 0);
  });
});
var mobile_screen = window.matchMedia('screen and (max-width: 525px)');
$(window).on('resize.map', function () {
  var scale = 1
    , $map = $('.map__karta')
    , orgn_width = 1340
    , curr_width = $map.width();
  if (mobile_screen.matches) {
    orgn_width = 290;
  } else {
    orgn_width = 1072;
  }
  scale = curr_width / orgn_width;
  $('.map__karta').css('transform', 'scale(' + scale + ')');
}).trigger('resize.map');
var mobile_1200 = window.matchMedia('screen and (max-width: 1200px)');
$(window).on('resize.map', function () {
  var scale = 1
    , $map = $('.map__karta')
    , orgn_width = 1340
    , curr_width = $map.width();
  if (mobile_1200.matches) {
    orgn_width = 0;
  } else {
    orgn_width = 1072;
  }
  scale = curr_width / orgn_width;
  $('.map__karta').css('transform', 'scale(' + scale + ')');
}).trigger('resize.map');
window.onload = function () {
  gsap.registerPlugin(ScrollTrigger);
  const time = gsap.utils.toArray('.time__left');
  const cloudleft = gsap.utils.toArray('.cloudleft');
  const dobro__right = gsap.utils.toArray('.park-right');
  const dobro__left = gsap.utils.toArray('.dobro__left');
  const dobro__subtitle = gsap.utils.toArray('.dobro__subtitle');
  const sun = gsap.utils.toArray('.sun');
  const dobro__title = gsap.utils.toArray('.dobro__title');
  const radyga = gsap.utils.toArray('.radyga');
  const cloudheader = gsap.utils.toArray('.cloudheader');
  const koleso = gsap.utils.toArray('.koleso');
  const dark = gsap.utils.toArray('.dark');
  const darkgreen = gsap.utils.toArray('.darkgreen');
  cloudleft.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(20%)rotate(-15deg)' }, { duration: 1, autoAlpha: 1, delay: 1.2, transform: 'translateY(0vw)rotate(-15deg)', });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  dobro__right.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateX(20%)' }, { duration: 1, autoAlpha: 1, delay: 1.25, transform: 'translateX(0vw)', });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  dobro__title.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(10%)' }, { duration: 1, autoAlpha: 1, delay: 1, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  sun.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)scale(0.7)' }, { duration: 0.9, autoAlpha: 1, transform: 'translateY(0vw)scale(1)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  cloudheader.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)' }, { duration: 0.9, autoAlpha: 1, delay: 1.25, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  koleso.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)' }, { duration: 0.9, autoAlpha: 1, delay: 1, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  dark.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)' }, { duration: 0.9, autoAlpha: 1, delay: 0.7, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  darkgreen.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)' }, { duration: 0.9, autoAlpha: 1, delay: 0.7, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  dobro__subtitle.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(10%)' }, { duration: 1, autoAlpha: 1, delay: 1.5, transform: 'translateY(0vw)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  time.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateX(20%)' }, { duration: 1, autoAlpha: 1, delay: 1, transform: 'translateX(0vw)', });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  dobro__left.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateX(20%)' }, { duration: 1, autoAlpha: 1, delay: 1, transform: 'translateX(0vw)', });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  radyga.forEach((box, i) => {
    const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%) rotate(-20deg)' }, { duration: 1, autoAlpha: 1, delay: 1, transform: 'translateY(0vw) rotate(-20deg)' });
    ScrollTrigger.create({
      trigger: box,
      animation: anim,
      toggleActions: 'play none none none',
      once: true,
    });
  });
  let mm = gsap.matchMedia();
  mm.add("(max-width: 525px)", () => {
    radyga.forEach((box, i) => {
      const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%) rotate(20deg)' }, { duration: 1, autoAlpha: 1, delay: 1, transform: 'translateY(0vw) rotate(20deg)' });
      ScrollTrigger.create({
        trigger: box,
        animation: anim,
        toggleActions: 'play none none none',
        once: true,
      });
    });
    cloudleft.forEach((box, i) => {
      const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(20%)rotate(5deg)' }, { duration: 1, autoAlpha: 1, delay: 1.2, transform: 'translateY(0vw)rotate(5deg)', });
      ScrollTrigger.create({
        trigger: box,
        animation: anim,
        toggleActions: 'play none none none',
        once: true,
      });
    });
    koleso.forEach((box, i) => {
      const anim = gsap.fromTo(box, { autoAlpha: 0, transform: 'translateY(15%)scale(0.1)' }, { duration: 0.9, autoAlpha: 1, delay: 1, transform: 'translateY(0vw)scale(0.4)' });
      ScrollTrigger.create({
        trigger: box,
        animation: anim,
        toggleActions: 'play none none none',
        once: true,
      });
    });
  });

  // Mouse Effects
  let sky = document.querySelector('#body'),
    cloud1 = document.querySelector('.cloud2');
  // Mouse Move Listener
  sky.addEventListener("mousemove", function (e) {
    let pageX = e.clientX - window.innerWidth / 2,
      pageY = e.clientY - window.innerHeight / 2;
    // cloud1.style.transform = 'translateX(' + (5 + pageX / 150) + '%) translateY(-' + (5 + pageY / 150) + '%)';
  });
}
window.addEventListener("mousemove", function (e) {
  var audio = document.querySelectorAll('.audio');
  audio.play();
})

$('.cloudleft').on('click', function () {
  $('.audio')[0].play()
})






